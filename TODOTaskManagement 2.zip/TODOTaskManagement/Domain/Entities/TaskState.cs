﻿namespace Domain.Entities
{
    public enum TaskState
    {
        Pending = 1,
        Completed = 2
    }
}
